﻿module.exports = async function () {
  // Root entry required for Functions host initialisation
};
